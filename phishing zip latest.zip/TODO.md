# TODO - PhishGuard AI

- [ ] Update `ml/train.py` so the training feature set exactly matches `ml/predict.py` / `ml/explain.py`:
  - [ ] Use `extract_url_features(url)` + `brand_similarity_features(url)`
  - [ ] Exclude `brand_best_match` from training features
  - [ ] Use correct label column (`phishing`)
  - [ ] Ensure `feature_columns` in the saved artifact matches the trained feature DataFrame columns
- [ ] (If needed) Adjust `ml/predict.py` only for any label/probability mapping mismatch (prefer no changes).
- [ ] Run smoke test / training and verify predictions run end-to-end.

