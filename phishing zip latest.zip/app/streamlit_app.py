"""
PhishGuard AI — Streamlit UI
Tabs: URL Scanner | Email Analyzer | SMS Scam Detector
"""
from __future__ import annotations

import sys
import os

# Ensure repo root is importable regardless of working directory
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from typing import Any, Dict

import streamlit as st

from ml.predict import predict_with_explanations
from ml.email_analyzer import analyze_email
from ml.sms_analyzer import analyze_sms

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="PhishGuard AI",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ---------------------------------------------------------------------------
# Custom CSS — minimal, accessible
# ---------------------------------------------------------------------------
st.markdown(
    """
    <style>
    .verdict-dangerous  { color: #d32f2f; font-weight: 700; font-size: 1.4rem; }
    .verdict-suspicious { color: #f57c00; font-weight: 700; font-size: 1.4rem; }
    .verdict-safe       { color: #2e7d32; font-weight: 700; font-size: 1.4rem; }
    .risk-bar-wrap { background: #e0e0e0; border-radius: 8px; height: 18px; width: 100%; }
    .risk-bar-fill { height: 18px; border-radius: 8px; }
    </style>
    """,
    unsafe_allow_html=True,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def verdict_color(verdict: str) -> str:
    v = verdict.lower()
    if v == "dangerous":
        return "verdict-dangerous"
    if v == "suspicious":
        return "verdict-suspicious"
    return "verdict-safe"


def risk_bar(score: float) -> str:
    """Return an HTML risk bar."""
    pct = max(0.0, min(100.0, float(score)))
    if pct >= 65:
        color = "#d32f2f"
    elif pct >= 35:
        color = "#f57c00"
    else:
        color = "#2e7d32"
    return (
        f'<div class="risk-bar-wrap">'
        f'<div class="risk-bar-fill" style="width:{pct:.1f}%;background:{color};"></div>'
        f"</div>"
        f"<small>{pct:.1f} / 100</small>"
    )


def verdict_badge(verdict: str) -> str:
    css = verdict_color(verdict)
    return f'<span class="{css}">{verdict.upper()}</span>'


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
st.markdown("# 🛡️ PhishGuard AI")
st.markdown("**Detect scams before you click.** — Real-time phishing detection for URLs, emails, and SMS.")
st.divider()

# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------
tab_url, tab_email, tab_sms = st.tabs(["🔗 URL Scanner", "📧 Email Analyzer", "📱 SMS Detector"])


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — URL Scanner
# ══════════════════════════════════════════════════════════════════════════════
with tab_url:
    st.subheader("Scan a Suspicious URL")
    st.caption("Paste any URL — no network request is made to the target site.")

    col_input, col_opts = st.columns([3, 1])
    with col_input:
        url_input = st.text_input(
            "URL",
            value="https://secure-paytm-login-verification.com",
            label_visibility="collapsed",
            placeholder="https://example.com/login",
        )
    with col_opts:
        top_k = st.number_input("Top reasons", min_value=1, max_value=10, value=5, step=1)

    scan_btn = st.button("🔍 Scan URL", type="primary", key="scan_url")

    if scan_btn:
        if not url_input.strip():
            st.error("Please enter a URL.")
        else:
            with st.spinner("Analyzing…"):
                result: Dict[str, Any] = predict_with_explanations(
                    url_input.strip(), top_k_reasons=int(top_k)
                )

            pred = result.get("prediction", "unknown")
            risk = result.get("risk_score")
            proba = result.get("probabilities", {})
            reasons = result.get("reasons", [])

            verdict = "Dangerous" if pred == "phishing" else "Safe"
            if risk is not None and 35 <= risk < 65:
                verdict = "Suspicious"

            st.divider()

            # Verdict row
            r1, r2, r3 = st.columns(3)
            with r1:
                st.markdown("**Verdict**")
                st.markdown(verdict_badge(verdict), unsafe_allow_html=True)
            with r2:
                st.markdown("**Risk Score**")
                if risk is not None:
                    st.markdown(risk_bar(risk), unsafe_allow_html=True)
                else:
                    st.write("N/A")
            with r3:
                st.markdown("**Confidence**")
                ph = float(proba.get("phishing", 0.0) or 0.0)
                lg = float(proba.get("legitimate", 0.0) or 0.0)
                # Ensure percentages always sum to 100%
                total = ph + lg
                if total <= 0:
                    ph_pct, lg_pct = 0.0, 100.0
                else:
                    ph_pct = (ph / total) * 100.0
                    lg_pct = (lg / total) * 100.0
                st.write(f"Phishing: `{ph_pct:.1f}%`")
                st.write(f"Legitimate: `{lg_pct:.1f}%`")

            st.divider()


            # Reasons + analysis framing
            is_phishing = pred == "phishing"
            reasons_header = "**Why is this risky?**" if is_phishing else "**Why is this considered safe?**"
            st.markdown(reasons_header)

            # Feature snapshot (collapsible)
            st.subheader("Top Reasons")
            REASON_LABELS = {
                "has_suspicious_keyword": "Contains suspicious phishing keywords",
                "brand_similarity": "Domain resembles a known brand",
                "url_length": "URL is unusually long",
                "suspicious_keyword_count": "Multiple phishing-related keywords detected",
                "num_hyphens": "Contains many hyphens",
                "https_usage": "Uses HTTPS encryption",
                "url_shortening": "Uses a URL shortening service",
                "is_ip_address": "Uses an IP address instead of a domain",                    "has_typosquatting": "Possible brand impersonation detected",
            }

            if reasons:
                for r in reasons:
                    if isinstance(r, dict):
                        reason = r.get("reason", "")
                        label = REASON_LABELS.get(reason, reason.replace("_", " ").title())
                        st.write(f"✓ {label}")
                    else:
                        label = REASON_LABELS.get(str(r), str(r).replace("_", " ").title())
                        st.write(f"✓ {label}")
            else:
                st.info("No explanation available.")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — Email Analyzer
# ══════════════════════════════════════════════════════════════════════════════
with tab_email:
    st.subheader("Analyze a Suspicious Email")
    st.caption("Paste the email content below. Nothing is sent to external servers.")

    e1, e2 = st.columns([2, 1])
    with e1:
        email_subject = st.text_input(
            "Subject line",
            placeholder="e.g. Urgent: Your account has been suspended",
            key="email_subject",
        )
    with e2:
        email_sender = st.text_input(
            "From / Sender",
            placeholder='e.g. PayPal Support <no-reply@evil-domain.com>',
            key="email_sender",
        )

    email_body = st.text_area(
        "Email body",
        height=200,
        placeholder=(
            "Paste the full email body here.\n\n"
            "Example:\n"
            "Dear Customer,\n"
            "Your account has been suspended. Click here immediately to verify your details:\n"
            "http://paypa1-secure-verify.com/login\n"
        ),
        key="email_body",
    )

    analyze_email_btn = st.button("🔍 Analyze Email", type="primary", key="analyze_email")

    if analyze_email_btn:
        if not email_body.strip():
            st.error("Please paste the email body.")
        else:
            with st.spinner("Analyzing email…"):
                report = analyze_email(
                    body=email_body,
                    subject=email_subject,
                    sender=email_sender,
                )

            st.divider()

            # Top row
            c1, c2 = st.columns([1, 2])
            with c1:
                st.markdown("**Verdict**")
                st.markdown(verdict_badge(report.verdict), unsafe_allow_html=True)
                st.markdown("**Risk Score**")
                st.markdown(risk_bar(report.risk_score), unsafe_allow_html=True)
            with c2:
                st.markdown("**Top Risk Reasons**")
                if report.top_reasons:
                    for reason in report.top_reasons:
                        st.markdown(f"- {reason}")
                else:
                    st.success("No phishing indicators found.")

            st.divider()

            # Sender details
            if report.sender_details or report.sender_spoofing:
                with st.expander("📨 Sender Analysis", expanded=True):
                    if report.sender_spoofing:
                        st.error("⚠️ Sender display name spoofs a known brand!")
                    for k, v in report.sender_details.items():
                        st.write(f"**{k.replace('_', ' ').title()}:** {v}")

            # URLs found
            if report.urls_found:
                with st.expander(f"🔗 URLs found in email ({len(report.urls_found)})", expanded=True):
                    for u in report.urls_found:
                        score = report.url_risk_scores.get(u, 0.0)
                        icon = "🔴" if score >= 65 else ("🟠" if score >= 35 else "🟢")
                        st.markdown(f"{icon} `{u}` — risk {score:.0f}/100")

            # Pattern breakdown (collapsible)
            with st.expander("📊 Pattern breakdown"):
                ind = report.raw_indicators
                cols = st.columns(3)
                cols[0].metric("Urgency patterns", ind.get("urgency_count", 0))
                cols[1].metric("Financial patterns", ind.get("financial_count", 0))
                cols[2].metric("Credential patterns", ind.get("credential_count", 0))
                cols2 = st.columns(3)
                cols2[0].metric("URLs found", ind.get("url_count", 0))
                cols2[1].metric("Max URL risk", f"{ind.get('max_url_risk', 0):.0f}/100")
                cols2[2].metric("Suspicious attachments", ind.get("attachment_count", 0))


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — SMS Detector
# ══════════════════════════════════════════════════════════════════════════════
with tab_sms:
    st.subheader("Scan a Suspicious SMS / Text Message")
    st.caption("Paste the full message text. Detects smishing (SMS phishing) patterns locally.")

    sms_text = st.text_area(
        "Message text",
        height=150,
        placeholder=(
            "Paste the SMS here.\n\n"
            "Example:\n"
            "URGENT: Your HDFC bank account is blocked. "
            "Verify now at http://hdfc-secure-verify.xyz or lose access permanently."
        ),
        key="sms_text",
    )

    analyze_sms_btn = st.button("🔍 Analyze SMS", type="primary", key="analyze_sms")

    if analyze_sms_btn:
        if not sms_text.strip():
            st.error("Please paste the SMS message.")
        else:
            with st.spinner("Analyzing SMS…"):
                sms_report = analyze_sms(sms_text.strip())

            st.divider()

            s1, s2 = st.columns([1, 2])
            with s1:
                st.markdown("**Verdict**")
                st.markdown(verdict_badge(sms_report.verdict), unsafe_allow_html=True)
                st.markdown("**Risk Score**")
                st.markdown(risk_bar(sms_report.risk_score), unsafe_allow_html=True)
            with s2:
                st.markdown("**Top Risk Reasons**")
                if sms_report.top_reasons:
                    for reason in sms_report.top_reasons:
                        st.markdown(f"- {reason}")
                else:
                    st.success("No smishing indicators detected.")

            st.divider()

            if sms_report.urls_found:
                with st.expander(f"🔗 URLs in message ({len(sms_report.urls_found)})", expanded=True):
                    for u in sms_report.urls_found:
                        score = sms_report.url_risk_scores.get(u, 0.0)
                        icon = "🔴" if score >= 65 else ("🟠" if score >= 35 else "🟢")
                        st.markdown(f"{icon} `{u}` — risk {score:.0f}/100")

            with st.expander("📊 Pattern breakdown"):
                ind = sms_report.raw_indicators
                col1, col2, col3 = st.columns(3)
                col1.metric("Urgency", ind.get("urgency_count", 0))
                col2.metric("Prize/Lottery", ind.get("prize_count", 0))
                col3.metric("Delivery scam", ind.get("delivery_count", 0))
                col4, col5, col6 = st.columns(3)
                col4.metric("Impersonation", ind.get("impersonation_count", 0))
                col5.metric("Financial", ind.get("financial_count", 0))
                col6.metric("URLs found", ind.get("url_count", 0))

# ---------------------------------------------------------------------------
# Footer
# ---------------------------------------------------------------------------
st.divider()
st.caption(
    "PhishGuard AI · All analysis runs locally — no data is sent to external servers. "
    "This tool provides heuristic risk signals; always apply human judgment."
)
